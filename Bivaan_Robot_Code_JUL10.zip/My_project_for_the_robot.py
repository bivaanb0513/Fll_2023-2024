"                      Importing Libraries                         "
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop 
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from MineStemLib import resetHeading
from MineStemLib import myHeading
"Creating Objects"
myPrimeHub = PrimeHub()

"Defining Variables"
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheel's axles track size. 
#This is the distance in mm between the center of each side wheel.
wheel_axle_dist = 125

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)
#left_color_sensor = ColorSensor(Port.E)
#right_color_sensor = ColorSensor(Port.F)

"Creating Objects using their commands"
drive_base = DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
drive_base.use_gyro(True)

"Writing/Calling Functions"
def leftAttachment(speed, angle):
    left_attachment_motor.run_angle(speed, angle, then=Stop.COAST, wait=True)

def rightAttachment(speed, angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

leftAttachment(50,180)
rightAttachment(150,90)

def run1():
    leftAttachment(50,180)
    rightAttachment(150,90)
    leftAttachment(80,360)
    leftAttachment(20,-90)
    rightAttachment(100,-135)

run1()

"The .settings() command has 4 parameters used to define the robot's movement:"
#*straight speed: How fast the robot drives when moving straight 
#*(in millimeters per second - mm/s)

#**straight acceleration: How fast the robot accelerates and decelerates when
#**traveling in a straight line (in millimeters per second squared - mm/s²)

#*** turn acceleration: How fast the robot accelerates and decelerates when
#***turning (in degrees per second squared - deg/s²)

#****turn rate: How fast the robot moves when turning (in degrees per second -
#***deg/s)

def run2():
    drive_base.settings(straight_speed=600,straight_acceleration=300,turn_rate=400,turn_acceleration=300)
    drive_base.straight(100)
    drive_base.turn(45)
    drive_base.stop()