"""Importing Libaries"""
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorDistanceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from MineStemLib import resetHeading
from MineStemLib import myHeading
"""Defining Varibles"""
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance
#in mm between the center of each side wheel.
wheel_axle_dist = 125
"""Creating Objects"""

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)
#left_color_sensor = ColorSensor(Port.E)
#right_color_sensor = ColorSensor(Port.F)
"""Writing/CallingFuctions"""
def leftAttachment (speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

def rightAttachment (speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)
    
def run1():
    leftAttachment(50, 180)
    rightAttachment(150,90)
    leftAttachment(20,-90)
    rightAttachment(100,135)

#run1()


def run2():
    drive_base.settings(straight_speed=600,straight_acceleration=300,turn_rate=400, turn_acceleration=300)
    drive_base.straight(100)

run2()