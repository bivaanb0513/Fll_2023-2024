"""Importing Libaries"""
from pybricks.hubs import MoveHub
from pybricks.pupdevices import Motor, ColorDistanceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
"""Defining Varibles"""
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance
#in mm between the center of each side wheel.
wheel_axle_dist = 125
"""Creating Objects"""

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.C)
#left_color_sensor = ColorSensor(Port.E)
#right_color_sensor = ColorSensor(Port.F)