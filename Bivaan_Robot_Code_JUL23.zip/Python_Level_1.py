"""Importing Libaries"""
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorDistanceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from MineStemLib import resetHeading
from MineStemLib import myHeading
"""Defining Varibles"""
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance
#in mm between the center of each side wheel.
wheel_axle_dist = 125
"""Creating Objects"""
myPrimehub = PrimeHub

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)
#left_color_sensor = ColorSensor(Port.E)
#right_color_sensor = ColorSensor(Port.F)
"""Creating Objects and Using Their Commands"""
drive_base = DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
drive_base.use_gyro(True)
"""Writing/CallingFuctions"""
def leftAttachment (speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

def rightAttachment (speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)
    
def run1():
    leftAttachment(1000, 10000)
run1()