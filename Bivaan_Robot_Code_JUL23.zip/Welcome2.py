def run1():
    straight straight (980)
    (700) turn